using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("3CX-DATEV Bridge")]
[assembly: AssemblyDescription("Integration zwischen 3CX Windows Softphone App (V20) und DATEV.")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("3CX-DATEV Bridge")]
[assembly: AssemblyCopyright("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

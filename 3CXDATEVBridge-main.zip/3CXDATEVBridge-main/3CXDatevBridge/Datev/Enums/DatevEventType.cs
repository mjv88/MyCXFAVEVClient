namespace DatevBridge.Datev.Enums
{
    internal enum DatevEventType
    {
        Dial,
        Drop
    }
}
